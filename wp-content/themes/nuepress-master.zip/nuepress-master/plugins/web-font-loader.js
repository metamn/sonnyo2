import WebFont from 'webfontloader'

WebFont.load({
  google: {
    families: ['Roboto:100,300,400', 'Roboto+Slab:300,400,700']
  }
})
