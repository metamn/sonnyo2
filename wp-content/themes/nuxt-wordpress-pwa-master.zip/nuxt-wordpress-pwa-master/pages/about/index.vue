<template>
  <div>
    <h1>About Page</h1>
    <p>The content of the page</p>
  </div>
</template>

<script>

export default {
}
</script>

<style>

</style>
